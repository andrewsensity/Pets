package com.platzi.pets.pojo;

import android.widget.ImageView;
import android.widget.TextView;

public class Pet {

    private int ivPet, ivBoneWhite, ivBoneOrange;
    private String tvName, tvRating;

    public Pet(int ivPet, String tvName, String tvRating) {
        this.ivPet = ivPet;
        this.tvName = tvName;
        this.tvRating = tvRating;
    }

    public int getIvPet() {
        return ivPet;
    }

    public void setIvPet(int ivPet) {
        this.ivPet = ivPet;
    }

    public int getIvBoneWhite() {
        return ivBoneWhite;
    }

    public void setIvBoneWhite(int ivBoneWhite) {
        this.ivBoneWhite = ivBoneWhite;
    }

    public int getIvBoneOrange() {
        return ivBoneOrange;
    }

    public void setIvBoneOrange(int ivBoneOrange) {
        this.ivBoneOrange = ivBoneOrange;
    }

    public String getTvName() {
        return tvName;
    }

    public void setTvName(String tvName) {
        this.tvName = tvName;
    }

    public String getTvRating() {
        return tvRating;
    }

    public void setTvRating(String tvRating) {
        this.tvRating = tvRating;
    }
}
