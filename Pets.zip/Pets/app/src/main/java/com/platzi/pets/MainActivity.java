package com.platzi.pets;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toolbar;
import java.util.ArrayList;

import com.platzi.pets.adapters.PetAdapter;
import com.platzi.pets.pojo.Pet;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Pet> pets;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        pets = new ArrayList<>();
        pets.add(new Pet(R.drawable.horse, "Arya Stark", "0"));
        pets.add(new Pet(R.drawable.bear, "Hodor", "0"));
        pets.add(new Pet(R.drawable.dolphin, "Jon Snow", "0"));
        pets.add(new Pet(R.drawable.eagle, "Sansa Stark", "0"));
        pets.add(new Pet(R.drawable.grampus, "Khal Drogo", "0"));

        LinearLayoutManager linearLayout = new LinearLayoutManager(this);
        linearLayout.setOrientation(RecyclerView.VERTICAL);

        recyclerView = (RecyclerView) findViewById(R.id.rvPet);
        PetAdapter adapter = new PetAdapter(pets);

        recyclerView.setLayoutManager(linearLayout);
        recyclerView.setAdapter(adapter);
    }
}