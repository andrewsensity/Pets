package com.platzi.pets.adapters;

import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.platzi.pets.R;
import com.platzi.pets.pojo.Pet;

import java.util.ArrayList;

public class PetAdapter extends RecyclerView.Adapter<PetAdapter.PetViewHolder>{

    public PetAdapter(ArrayList<Pet> pets) {
        this.pets = pets;
    }

    ArrayList<Pet> pets;

    @NonNull
    @Override
    public PetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_pet, parent, false);
        return new PetViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PetViewHolder holder, int position) {
        Pet pet = pets.get(position);
        holder.ivPet.setImageResource(pet.getIvPet());
        holder.tvName.setText(String.valueOf(pet.getTvName()));
        holder.tvRating.setText(String.valueOf(pet.getTvRating()));
    }

    @Override
    public int getItemCount() {
        return pets.size();
    }

    public static class PetViewHolder extends RecyclerView.ViewHolder{
        private ImageView ivPet;
        private TextView tvName, tvRating;

        public PetViewHolder(@NonNull View itemView) {
            super(itemView);
            ivPet =     (ImageView) itemView.findViewById(R.id.ivPet);
            tvName =    (TextView) itemView.findViewById(R.id.tvName);
            tvRating =  (TextView) itemView.findViewById(R.id.tvRating);
        }
    }
}
